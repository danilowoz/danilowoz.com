const { width, height } = document.body.getBoundingClientRect();

window.addEventListener("mousemove", (event) => {
  const { clientX, clientY } = event;

  document.body.style.setProperty("--x", `${(clientX / width) * 100}%`);
  document.body.style.setProperty("--y", `${(clientY / height) * 100}%`);
});
