import "./styles.css";

import ALBUMS from "./albums.json";
const reversedAlbums = ALBUMS.reverse();

export default function App() {
  return (
    <div className="scroller" style={{ "--total": reversedAlbums.length }}>
      <h2 className="album-position"></h2>

      {reversedAlbums.map((item, i) => (
        <div key={i} className="album-item">
          <div
            className="album-wrapper"
            style={{
              "--index": i,
              "--image-url": `url(${item.image})`,
            }}
          >
            <div className="album-name">
              <p>{item.album}</p>
              <span>{item.artist}</span>
            </div>

            <div className="cover">
              <div className="entry-exit entry-1">
                <div className="entry-exit entry-2">
                  <div className="entry-exit entry-3">
                    <div className="entry-exit exit-1">
                      <div className="entry-exit exit-2">
                        <div className="entry-exit exit-3 cover-wrapper">
                          <div className="cover-shine_front" />
                          <img
                            className="cover-image"
                            src={item.image}
                            alt=""
                          />
                          <div className="cover-shine_back" />
                          <div className="cover-back cover-back_1" />
                          <div className="cover-back cover-back_2" />
                          <div className="cover-back cover-back_3" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
