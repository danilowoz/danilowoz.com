import { CSSProperties, useState } from "react";
import "./styles.css";
import { LayoutGroup, motion } from "framer-motion";

const ITEMS = ["Playlist", "By you", "By Spotify", "Liked songs"];

export default function App() {
  const [activeItems, setActiveItems] = useState<string[]>([ITEMS[0]]);

  const sortedItems = [
    ...activeItems,
    ...ITEMS.filter((item) => !activeItems.includes(item)),
  ];

  const renderButton = (item: string, index: number) => (
    <motion.button
      layout
      key={item}
      onClick={() =>
        setActiveItems((prev) =>
          prev.includes(item) ? prev.filter((i) => i !== item) : [...prev, item]
        )
      }
      style={{ "--index": index } as CSSProperties}
      className={"item" + (activeItems.includes(item) ? " active" : "")}
      transition={{ duration: 0.3 }}
      initial={{ paddingLeft: 12 }}
      animate={{
        paddingLeft: index > 0 && activeItems.includes(item) ? 32 : 12,
      }}
    >
      <span>{item}</span>
    </motion.button>
  );

  return (
    <LayoutGroup>
      <div className="stack">{sortedItems.map(renderButton)}</div>
      <svg xmlns="http://www.w3.org/2000/svg" version="1.1">
        <defs>
          <filter id="melt">
            <feGaussianBlur in="SourceGraphic" stdDeviation="3" result="blur" />
            <feColorMatrix
              in="blur"
              mode="matrix"
              values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 19 -9"
              result="goo"
            />
            <feComposite in="SourceGraphic" in2="goo" operator="atop" />
          </filter>
        </defs>
      </svg>
    </LayoutGroup>
  );
}
